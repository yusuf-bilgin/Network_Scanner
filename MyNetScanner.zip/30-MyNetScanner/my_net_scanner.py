import scapy.all as scapy
import optparse
# Asamalar:
# 1) arp_request
# 2) broadcast
# 3) response

def get_user_input():
    parse_object = optparse.OptionParser()
    parse_object.add_option("-i","--ipaddress",dest="ip_address",help="Enter IP Address")

    (user_input,arguments) = parse_object.parse_args()

    if not user_input.ip_address:
        print("Enter IP Address!!")
    return user_input

# ARP paketimizi olusturalim
def scan_my_network(ip):
    my_arp_request_packet = scapy.ARP(pdst=ip)
    # ARP yi kullanirken bazi girdiler olusturmaliyiz.
    # ARP, "Bu IP kimde var?" seklinde calisiyordu. Yani scapy.ARP icerisine bir IP adresi vermemiz gerekiyor.
    # scapy.ls(scapy.ARP())   #scapy.ARP hakkinda bilgi alma komutu (pdst yi buradan gorduk)

    # 2.Asama (yayin yapmak-broadcast)

    my_broadcast_packet = scapy.Ether(dst="ff:ff:ff:ff:ff:ff") # agin tamamina yayin
    # scapy.ls(scapy.Ether())
    # Su an ARP sorgusunu yukaridaki adrese yollayip cevaplari almamiz gerek
    # Scapy bu tarz iki tane istegi birlestirmek icin bir method sunuyor.
    combined_packet = my_broadcast_packet/my_arp_request_packet  # Scapy'de boyle :d
    # iki paketi birlestirdikten sonra geriye bunu yollamak ve cevaplarini islemek.
    (answered_list,unanswered_list)  = scapy.srp(combined_packet,timeout=1) # Bu sekilde cevap verilen ve verilmeyen paketleri gorebilecegiz.
    # timeout=1 cevap verilmezse bekleme devam et manasina geliyor.
    answered_list.summary()

user_ip_address = get_user_input()
scan_my_network(user_ip_address.ip_address)